# Remote Sanex

1. Buka folder ini di Android Studio (File > Open), tunggu Gradle sync.
2. Colok HP (USB debugging aktif) lalu Run, atau Build > Build APK(s).
3. APK ada di app/build/outputs/apk/debug/app-debug.apk

Kode tombol bisa diubah lewat tombol "Atur" di app.
