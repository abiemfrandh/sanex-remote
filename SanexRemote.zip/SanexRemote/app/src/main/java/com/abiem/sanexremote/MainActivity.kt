package com.abiem.sanexremote

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.hardware.ConsumerIrManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private data class Key(val id: String, val label: String, val defaultCode: String)

    private val keys = listOf(
        Key("power", "On/Off", "00FFA25D"),
        Key("lamp", "Lamp", "00FF00FF"),
        Key("speed", "Speed", "00FFE01F"),
        Key("mode", "Mode", "00FF906F"),
        Key("swing", "Swing", "00FF30CF"),
        Key("timer", "Timer", "00FF7A85")
    )

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private var ir: ConsumerIrManager? = null

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("codes", Context.MODE_PRIVATE)
        ir = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        setContentView(buildUi())
        if (ir?.hasIrEmitter() != true) {
            status.text = "HP ini tidak punya pemancar IR"
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(16))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        titles.addView(TextView(this).apply {
            text = "Remote Sanex"
            textSize = 20f
        })
        titles.addView(TextView(this).apply {
            text = "Arahkan IR HP ke kipas"
            textSize = 12f
            alpha = 0.7f
        })
        header.addView(titles)
        header.addView(Button(this).apply {
            text = "Atur"
            setOnClickListener { showSettings() }
        })
        root.addView(header)

        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
            ).apply { topMargin = dp(16) }
        }
        keys.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
                )
            }
            pair.forEach { key ->
                row.addView(makeButton(key))
            }
            grid.addView(row)
        }
        root.addView(grid)

        status = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 12f
            alpha = 0.7f
            text = "Siap"
        }
        root.addView(status)
        return root
    }

    private fun makeButton(key: Key): Button = Button(this).apply {
        text = key.label
        textSize = 18f
        isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
            .apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
        if (key.id == "power") {
            setBackgroundColor(Color.parseColor("#C62828"))
            setTextColor(Color.WHITE)
        }
        setOnClickListener { send(key) }
    }

    private fun codeFor(key: Key) = prefs.getString("code_${key.id}", key.defaultCode) ?: key.defaultCode

    private fun send(key: Key) {
        buzz()
        val manager = ir
        if (manager == null || !manager.hasIrEmitter()) {
            status.text = "HP ini tidak punya pemancar IR"
            return
        }
        val code = Nec.parse(codeFor(key))
        if (code == null) {
            status.text = "Kode ${key.label} tidak valid"
            return
        }
        val msbFirst = prefs.getBoolean("msb_first", true)
        try {
            manager.transmit(Nec.CARRIER_HZ, Nec.pattern(code, msbFirst))
            status.text = "Sinyal terkirim: ${key.label}"
        } catch (e: Exception) {
            status.text = "Gagal mengirim: ${e.message}"
        }
    }

    @Suppress("DEPRECATION")
    private fun buzz() {
        val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        if (vibrator == null || !vibrator.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= 26) {
            vibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            vibrator.vibrate(30)
        }
    }

    private fun showSettings() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        val fields = HashMap<String, EditText>()
        keys.forEach { key ->
            container.addView(TextView(this).apply {
                text = key.label
                textSize = 13f
            })
            val field = EditText(this).apply {
                setText(codeFor(key))
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                setSingleLine()
            }
            fields[key.id] = field
            container.addView(field)
        }
        val msb = CheckBox(this).apply {
            text = "Urutan bit remote generik (matikan kalau kipas tidak merespons)"
            isChecked = prefs.getBoolean("msb_first", true)
        }
        container.addView(msb)

        AlertDialog.Builder(this)
            .setTitle("Kode tombol (NEC, 8 digit hex)")
            .setView(ScrollView(this).apply { addView(container) })
            .setPositiveButton("Simpan") { _, _ ->
                val editor = prefs.edit()
                var allValid = true
                keys.forEach { key ->
                    val text = fields.getValue(key.id).text.toString().trim().uppercase()
                    if (Nec.parse(text) == null) allValid = false
                    else editor.putString("code_${key.id}", text)
                }
                editor.putBoolean("msb_first", msb.isChecked)
                editor.apply()
                Toast.makeText(
                    this,
                    if (allValid) "Tersimpan" else "Ada kode yang tidak valid, tidak disimpan",
                    Toast.LENGTH_SHORT
                ).show()
            }
            .setNeutralButton("Reset") { _, _ ->
                prefs.edit().clear().apply()
                Toast.makeText(this, "Kode dikembalikan ke awal", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
