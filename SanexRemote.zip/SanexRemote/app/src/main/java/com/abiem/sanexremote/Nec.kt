package com.abiem.sanexremote

object Nec {
    const val CARRIER_HZ = 38000

    private const val HEADER_MARK = 9000
    private const val HEADER_SPACE = 4500
    private const val BIT_MARK = 560
    private const val ZERO_SPACE = 560
    private const val ONE_SPACE = 1690

    fun parse(hex: String): Long? {
        val clean = hex.trim().removePrefix("0x").removePrefix("0X")
        if (clean.length != 8) return null
        return clean.toLongOrNull(16)
    }

    /**
     * code: 32-bit NEC, ditulis seperti di app lain (contoh 00FFA25D).
     * msbFirst = true  -> bit dikirim dari bit paling kiri (format remote generik, default).
     * msbFirst = false -> tiap byte dikirim dari bit paling kanan (NEC murni).
     */
    fun pattern(code: Long, msbFirst: Boolean): IntArray {
        val out = ArrayList<Int>(70)
        out.add(HEADER_MARK)
        out.add(HEADER_SPACE)
        for (i in 0 until 32) {
            val bit = if (msbFirst) {
                ((code shr (31 - i)) and 1L).toInt()
            } else {
                val byteValue = ((code shr (24 - 8 * (i / 8))) and 0xFFL).toInt()
                (byteValue shr (i % 8)) and 1
            }
            out.add(BIT_MARK)
            out.add(if (bit == 1) ONE_SPACE else ZERO_SPACE)
        }
        out.add(BIT_MARK)
        return out.toIntArray()
    }
}
